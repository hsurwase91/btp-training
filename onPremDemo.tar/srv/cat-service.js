const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {
    this.on(['READ','CREATE','UPDATE','DELETE'], 'EmpDetailsSet', async req => {
        try {
            const empDetService = await cds.connect.to("Z_CRUD_EMP_DETAILS_DEMO_SRV");
            let result = empDetService.run(req.query);
            return result;
        }
        catch (error) {
            req.error(error.status, error.message);
        }
    });
});