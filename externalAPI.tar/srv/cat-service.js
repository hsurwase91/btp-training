const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
    const northwindSrv = await cds.connect.to('Northwind');
    this.on('READ', 'Customers', async req => {
        try {
            let result = await northwindSrv.run(req.query);
            return result;
        }
        catch (error) {
            req.error('500', error);
        }
    });
});