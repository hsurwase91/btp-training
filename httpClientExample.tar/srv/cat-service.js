const cds = require('@sap/cds'); 
const httpClient = require('@sap-cloud-sdk/http-client');
module.exports = cds.service.impl(async function () { 
    this.on('getSalesOrders', async req =>{ 
        try{ 
            const service = await cds.connect.to('APIHubSandbox_SRV'); 
            let response =  await httpClient.executeHttpRequest(
                {destinationName : service.destination },
                {
                    method : "get",
                    //url : `${salesOrderAPIDestination.path}/A_SalesOrder?$top=10`, 
                    url : "/s4hanacloud/sap/opu/odata/sap/API_SALES_ORDER_SRV/A_SalesOrder?$top=10",
                    headers :{
                        requestConfig: {
                            DataServiceVersion: "2.0",
                            Accept: "application/json"
                        }
                    }
                }
            ); 
            //Extract response
            if (response.status === 200) {
                let salesOrders = response.data.d.results.map(x => {
                    return {
                        SalesOrder: x.SalesOrder,
                        SalesOrderType: x.SalesOrderType,
                        SalesOrganization: x.SalesOrganization,
                        SoldToParty: x.SoldToParty
                    }
                });
                return salesOrders;

            } else {
                req.reject(response.status, response.statusText);
            }
            return result; 
        } 
        catch(error){ 
            req.error('500', error.message); 
        } 
    }); 
}); 
