const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
    //Access Entities from Service
    const { SrvCustomers, SalesOrders, SalesOrderItems } = this.entities('CatalogService');
    //Access Entities from DB
    const db = await cds.connect.to('db');
    const { DBCustomers } = db.entities('my.salesorder');
    this.on('getSrvCustomers', async (req) => {
        try {
            let customerQuery = cds.parse.cql(`SELECT customerNo, customerName from ${SrvCustomers}`);
            let customerRes = await cds.db.run(customerQuery);
            if (customerRes.length > 0) {
                console.log(customerRes);
            }
            return customerRes;
        }
        catch (error) {
            req.error(500, error.message);
        }
    });

    this.on('getDBCustomers', async (req) => {
        try {
            let customerQuery = cds.parse.cql(`SELECT customerNo, customerName from ${DBCustomers}`);
            let customerRes = await cds.db.run(customerQuery);
            if (customerRes.length > 0) {
                console.log(customerRes);
            }
            return customerRes;
        }
        catch (error) {
            req.error(500, error.message);
        }
    });

    this.after('READ','SalesOrders',async(data,req)=>{
        //Scenario-1 Populate Virtual element based on SalesOrderItems
        //Compute total quantity of each sales order and check if it is greater than 200.
        //Set virtual properties (totalQuantity & overBookingInd) 
        try{
            const overBookingLimit = 200;
            let totQuantityQuery = cds.parse.cql(`SELECT salesOrder_ID, sum(quantity) as totalQuantity from ${SalesOrderItems} group by salesOrder_ID`);
            let totQuantityRes = await cds.db.run(totQuantityQuery);
            //check if single salesorder or array of salesorders are returned
            if (Array.isArray(data)) {
                data.forEach(each=>{
                    let totQuantity = totQuantityRes.find(element => element.salesOrder_ID == each.ID); 
                    each.overBookingInd = ((totQuantity !== undefined) && (totQuantity.totalQuantity > overBookingLimit)) ? true : false;
                    each.totalQuantity = (totQuantity !== undefined) ? totQuantity.totalQuantity : 0;
                });
            }
            else{
                let totQuantity = totQuantityRes.find(element => element.salesOrder_ID == data.ID);
                data.overBookingInd = ((totQuantity !== undefined) && (totQuantity.totalQuantity > overBookingLimit)) ? true : false;
                data.totalQuantity = (totQuantity !== undefined) ? totQuantity.totalQuantity : 0;
            }
            return data;
        }
        catch(error){
            req.error(500,error.message);
        }
    });

    this.before('CREATE', 'SalesOrders', async (req) => {
        try {//Scenario-3 :SalesOrderID Validation
            if (req.data.ID == undefined || req.data.ID == 0 ) {
                let maxIDQuery = cds.parse.cql(`SELECT max(ID) as maxID from ${SalesOrders}`);
                let maxIDRes = await cds.db.run(maxIDQuery);
                if (maxIDRes.length > 0) {
                    req.data.ID = maxIDRes[0].maxID + 1;
                }
            }
        }
        catch (error) {
            req.error('500', error);
        }
    });


});